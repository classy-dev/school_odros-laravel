<?php

namespace App\Http\Controllers\School;
use Illuminate\Support\Facades\DB;
use App\Models\Fair;
use App\Models\University;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
//added by @Prasad
use App\Models\School;
use App\Models\User;
use App\Mail\SchoolFiarupdateMail;
use Illuminate\Support\Facades\Mail;

class UniversityController extends Controller
{
    /**
     * get list of school fairs
     */
    public function index() {

        $fairs = Fair::where('school_id', Auth::user()->school_id)->get();
        $school = School::find(Auth::user()->school_id);
        $univ_lists = University::get();
        $query = DB::table('functions')->whereNotNull('school_suspend')->get('school_suspend');
        return view('school.university.index', compact(['fairs','school','univ_lists','query']));

    }

    // public function sendNotifyToUniversities($fair) {
    //     $school_info = School::where('id', $fair->school_id)->get()->first();
    //     $universities = User::where('role','university')->select('email')->get();
    //     $email_content = array(
    //         'schoolname' => $school_info->name,
    //         'startdate' => Carbon::createFromFormat('m/d/Y H:i a', $fair->start_date)->format('Y-m-d H:i'),
    //         'starttime' => Carbon::createFromFormat('m/d/Y H:i a', $fair->start_date)->format('H:i a'),
    //         'enddate'=> Carbon::createFromFormat('m/d/Y H:i a', $fair->end_date)->format('Y-m-d H:i'),
    //         'endtime'=> Carbon::createFromFormat('m/d/Y H:i a', $fair->end_date)->format('H:i a'),
    //     );
    //     Mail::to($universities)->send(new SchoolFiarupdateMail($email_content));
    // }
    public function confirmed_universities() {

        // return view('admin.manage_university.confirmed_universities');
        // $fairs = Fair::where('school_id', Auth::user()->school_id)->get();
        // $school = School::find(Auth::user()->school_id);
        // $univ_lists = University::get();
        // $query = DB::table('functions')->whereNotNull('school_suspend')->get('school_suspend');
        // return view('school.university.confirmed_universities');
        $fairs = Fair::where('school_id', Auth::user()->school_id)->get();
        $school = School::find(Auth::user()->school_id);
        $univ_lists = University::get();
        $query = DB::table('functions')->whereNotNull('school_suspend')->get('school_suspend');
        return view('school.university.confirmed_universities', compact(['fairs','school','univ_lists','query']));

    }
    public function students_registration() {

        // return view('admin.manage_university.confirmed_universities');
        // $fairs = Fair::where('school_id', Auth::user()->school_id)->get();
        // $school = School::find(Auth::user()->school_id);
        // $univ_lists = University::get();
        // $query = DB::table('functions')->whereNotNull('school_suspend')->get('school_suspend');
        // return view('school.university.confirmed_universities');
        $fairs = Fair::where('school_id', Auth::user()->school_id)->get();
        $school = School::find(Auth::user()->school_id);
        $univ_lists = University::get();
        $query = DB::table('functions')->whereNotNull('school_suspend')->get('school_suspend');
        return view('school.university.students_registration', compact(['fairs','school','univ_lists','query']));

    }
    public function workshop_list() {

        $fairs = Fair::where('school_id', Auth::user()->school_id)->get();
        $school = School::find(Auth::user()->school_id);
        $univ_lists = University::get();
        $query = DB::table('functions')->whereNotNull('school_suspend')->get('school_suspend');
        return view('school.workshop.index', compact(['fairs','school','univ_lists','query']));

    }

}
