<?php

namespace App\Http\Controllers\School;
use Illuminate\Support\Facades\DB;
use App\Models\Fair;
use App\Models\University;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
//added by @Prasad
use App\Models\School;
use App\Models\User;
use App\Mail\SchoolFiarupdateMail;
use Illuminate\Support\Facades\Mail;

class FairController extends Controller
{
    /**
     * get list of school fairs
     */
    public function index() {

        $fairs = Fair::where('school_id', Auth::user()->school_id)->get();
        $school = School::find(Auth::user()->school_id);
        $query = DB::table('functions')->whereNotNull('school_suspend')->get('school_suspend');
        return view('school.fair.index', compact(['fairs','school','query']));

    }

    /**
     * show edit fair form page
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function edit($id) {
        $fair = Fair::where('school_id', Auth::user()->school_id)
            ->where('id', $id)->first();
        $school = School::where('id', Auth::user()->school_id)->get()->first();

        //dd($fair);
        $start_date_carbon = Carbon::createFromFormat('Y-m-d H:i:s', $fair->start_date);
        $start_date = $start_date_carbon->format('m/d/Y');
        $start_time = $start_date_carbon->format('H:i a');

        $end_date_carbon = Carbon::createFromFormat('Y-m-d H:i:s', $fair->end_date);
        $end_date = $end_date_carbon->format('m/d/Y');
        $end_time = $end_date_carbon->format('H:i a');

        return view('school.fair.edit', compact([
            'fair', 'start_date', 'start_time', 'end_date', 'end_time','school'
        ]));
    }


    public function update(Request $request, $id) {

        $validator = Validator::make($request->all(), [
            'start_date' => 'bail|required|date',
            'start_time' => 'bail|required',
            'end_date' => 'bail|required|date|after_or_equal:start_date',
            'end_time' => 'bail|required',
            'students_grade12_number' => 'bail|required|numeric|min:1',
            'students_grade11_number' => 'bail|required|numeric|min:1',
            'universities_max' => 'bail|required|numeric|min:1'
        ]);

        if ($validator->fails()) {
            return redirect()->route('school.update_fair')
                ->withErrors($validator)
                ->withInput();
        }

        $start_date = $request->get('start_date').' '.$request->get('start_time');
        $start_date = Carbon::createFromFormat('m/d/Y H:i a', $start_date)
            ->format('Y-m-d H:i');

        $end_date = $request->get('end_date').' '.$request->get('end_time');
        $end_date = Carbon::createFromFormat('m/d/Y H:i a', $end_date)
            ->format('Y-m-d H:i');

        $fair = Fair::where('school_id', Auth::user()->school_id)
            ->where('id', $id)
            ->update([
                'start_date' => $start_date,
                'end_date' => $end_date,
                'students_grade12_number' => $request->get('students_grade12_number'),
                'students_grade11_number' => $request->get('students_grade11_number'),
                'universities_max' => $request->get('universities_max'),
            ]);

        return redirect()->route('school.fairs_list')->with([
            'error' => false,
            'message' => 'Fair updated successfully !'
        ]);

        //Updated by @Prasad
        //Send notification to all Universities using mail
        $this->sendNotifyToUniversities($fair);
    }
    public function sendNotifyToUniversities($fair) {
        $school_info = School::where('id', $fair->school_id)->get()->first();
        $universities = User::where('role','university')->select('email')->get();
        $email_content = array(
            'schoolname' => $school_info->name,
            'startdate' => Carbon::createFromFormat('m/d/Y H:i a', $fair->start_date)->format('Y-m-d H:i'),
            'starttime' => Carbon::createFromFormat('m/d/Y H:i a', $fair->start_date)->format('H:i a'),
            'enddate'=> Carbon::createFromFormat('m/d/Y H:i a', $fair->end_date)->format('Y-m-d H:i'),
            'endtime'=> Carbon::createFromFormat('m/d/Y H:i a', $fair->end_date)->format('H:i a'),
        );
        Mail::to($universities)->send(new SchoolFiarupdateMail($email_content));
    }

    /**
     * show create fair form page
     */
    public function create() {
        $school = School::find(Auth::user()->school_id);
        return view('school.fair.create',compact('school'));
    }

    public function store(Request $request) {

        $validator = Validator::make($request->all(), [
            'start_date' => 'bail|required|date',
            'start_time' => 'bail|required',
            'end_date' => 'bail|required|date|after_or_equal:start_date',
            'end_time' => 'bail|required',
            'students_grade12_number' => 'bail|required|numeric|min:1',
            'students_grade11_number' => 'bail|required|numeric|min:1',
            'universities_max' => 'bail|required|numeric|min:1'
        ]);

        if ($validator->fails()) {
            return redirect()->route('school.create_fair')
                ->withErrors($validator)
                ->withInput();
        }

        $start_date = $request->get('start_date').' '.$request->get('start_time');
        $start_date = Carbon::createFromFormat('m/d/Y H:i a', $start_date)
            ->format('Y-m-d H:i');

        $end_date = $request->get('end_date').' '.$request->get('end_time');
        $end_date = Carbon::createFromFormat('m/d/Y H:i a', $end_date)
            ->format('Y-m-d H:i');

        Fair::create([
            'start_date' => $start_date,
            'end_date' => $end_date,
            'students_grade12_number' => $request->get('students_grade12_number'),
            'students_grade11_number' => $request->get('students_grade11_number'),
            'universities_max' => $request->get('universities_max'),
            'school_id' => Auth::user()->school_id
        ]);

        return redirect()->route('school.fairs_list')->with([
            'error' => false,
            'message' => 'Fair created successfully !'
        ]);
    }

    /**
     * get list of participants universities
     *
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function participants($id) {

        $universities = University::select('universities.*','users.email as useremail','users.name as username','users.phone as userphone')
                        ->leftjoin('users','users.university_id','=','universities.id')->whereHas('invitations', function($query) use ($id){
            $query->where('accepted', true)->where('fair_id', $id);
        })->get();

        $school = School::where('id', Auth::user()->school_id)->get()->first();        
        return view('school.fair.participants', compact('universities','school'));
    }
}
