<?php

namespace App\Http\Controllers\Admin;
use Illuminate\Support\Facades\DB;
use App\Models\Fair;
use App\Models\University;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
//added by @Prasad
use App\Models\School;
use App\Models\User;
use App\Mail\SchoolFiarupdateMail;
use Illuminate\Support\Facades\Mail;

class ManageUniversityController extends Controller
{
    /**
     * get list of school fairs
     */
    public function index() {

        $fairs = Fair::where('school_id', Auth::user()->school_id)->get();
        $school = School::find(Auth::user()->school_id);
        $universities = University::get();
        $query = DB::table('functions')->whereNotNull('university_suspend')->get('university_suspend');
        return view('admin.manage_university.index', compact(['fairs','school','universities','query']));

    }

    public function edit($id) {
        $univ = University::where('id',$id)->get();
        return view('admin.manage_university.edit_university', compact(['univ']));
    }
    public function suspend(Request $request)
    {
                 $id = $request->name;
                 $find = DB::table('functions')->where('school_suspend',$id)->value('school_suspend');
                 if($find !== null){
                    DB::table('functions')->where('school_suspend', $id )->delete();
                    $ids = "del";
                 }else{
                        DB::table('functions')->insert(
                                            ['school_suspend' => $id]
                                        );
                                        $ids = "add";
                 }
                
                
               return response()->json(['success'=>$ids]);
    }
    public function suspend1(Request $request)
    {
                 $id = $request->name;
                 $find = DB::table('functions')->where('university_suspend',$id)->value('university_suspend');
                 if($find !== null){
                    DB::table('functions')->where('university_suspend', $id )->delete();
                    $ids = "del";
                 }else{
                        DB::table('functions')->insert(
                                            ['university_suspend' => $id]
                                        );
                                        $ids = "add";
                 }
                
                
               return response()->json(['success'=>$ids]);
    }
    public function update(Request $request, $id) {

        $validator = Validator::make($request->all(), [
            'univ_name' => 'required',            
            'phone' => 'required',
            'email' => 'required',
            'website' => 'required',
            'map_link' => 'required',
        ]);

        if ($validator->fails()) {
            return redirect()->route('admin.edit_univ', ['id' => $id])
                ->withErrors($validator)
                ->withInput();
        }

        $univ_name = $request->get('univ_name');
        $phone = $request->get('phone');
        $email = $request->get('email');
        $website = $request->get('website');
        $map_link = $request->get('map_link');

        $compus = json_encode($request->get('compus'));
        $country = json_encode($request->get('country'));
        $city = json_encode($request->get('city'));
        $address = json_encode($request->get('address'));

        $university = University::where('id', $id)
            ->update([
                'name' => $univ_name,
                'email' => $email,
                'phone' => $phone,
                'website' => $website,
                'map_link' => $map_link,
                'compus' => $compus,
                'country' => $country,
                'city' => $city,
                'address' => $address,
                'user_id' => Auth::user()->id
            ]);

        return redirect()->route('admin.manage_university')->with([
            'error' => false,
            'message' => 'Unversity updated successfully !'
        ]);

        //Updated by @Prasad
        //Send notification to all Universities using mail
        $this->sendNotifyToUniversities($university);
    }
    public function update_packages() {

        // $fairs = Fair::where('school_id', Auth::user()->school_id)->get();
        // $school = School::find(Auth::user()->school_id);
        // $universities = University::get();
        // $query = DB::table('functions')->whereNotNull('university_suspend')->get('university_suspend');
        // var_dump("test");exit();
        return view('admin.manage_university.update_packages');

    }
    public function edit_counselor() {

        // $fairs = Fair::where('school_id', Auth::user()->school_id)->get();
        // $school = School::find(Auth::user()->school_id);
        // $universities = University::get();
        // $query = DB::table('functions')->whereNotNull('university_suspend')->get('university_suspend');
        // var_dump("test");exit();
        return view('admin.manage_university.edit_counselor');

    }
   
    
}
